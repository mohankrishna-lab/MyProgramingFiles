package reguralgeoshapes;

public class Square implements Shape
{
	public void drawn()
	{
		System.out.print("square shape drawn with ");
	}
}
