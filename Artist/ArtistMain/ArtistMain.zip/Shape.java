package reguralgeoshapes;

public interface Shape 
{
	void drawn();
}
