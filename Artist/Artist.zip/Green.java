package reguralgeoshapes;

public class Green implements Color
{
	public void fill()
	{
		System.out.print("green color");
		System.out.println();
	}
}
