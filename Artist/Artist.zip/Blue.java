package reguralgeoshapes;

public class Blue implements Color
{
	public void fill()
	{
		System.out.print(" blue color");
		System.out.println();
	}
}
