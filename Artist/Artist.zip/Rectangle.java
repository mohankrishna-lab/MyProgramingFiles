package reguralgeoshapes;

public class Rectangle implements Shape
{
	public void drawn()
	{
		System.out.print("rectangle shape drawn with ");
	}
}
