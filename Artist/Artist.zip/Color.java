package reguralgeoshapes;

public interface Color
{
	void fill();
}
