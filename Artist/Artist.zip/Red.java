package reguralgeoshapes;

public class Red implements Color
{
	public void fill()
	{
		System.out.print("red color");
		System.out.println();
	}
}
