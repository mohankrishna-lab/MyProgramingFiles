class Stars 
{
	public static void main(String[] args) 
	{
		lines = 2;
		String spaces = " ";

		for (int i = 1;i <= lines ;i++ )
		{
			
			System.out.println(spaces + "*");
		}
	}
}
