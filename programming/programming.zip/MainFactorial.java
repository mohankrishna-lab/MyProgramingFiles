import java.util.Scanner;

class MainFactorial 
{
	public static void main(String[] args) 
	{
		int num = readNum();
		System.out.println("factorial number of " + num + " is:" + factorial(num));
	}

	public static int readNum()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		return sc.nextInt();

	}

	public static int factorial(int num)
	{
		int fact = 1;
		if (num == 0 || num == 1)
		{
			return fact;
		}
		else
		{
			for (int i = num;i>=1 ;i-- )
			{
				fact *= i;
			}
			return fact;
		}
	}
}
