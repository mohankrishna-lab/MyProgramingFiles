class AddingElementArray 
{
	public static void main(String[] args) 
	{
		int[] a = {6 , 8 , 9 , 5 , 7};

		int pos = 3;
		
		int ele = 67;
		
		int[] b = addElementArray(a , pos , ele);

		for (int i = 0 ;i < b.length ;i++ )
		{
			System.out.println(b[i]);
		}
	}

	public static int[] addElementArray(int[] a , int pos , int ele)
	{
		int[] b = new int[a.length + 1];

		int i;

		for (i = 0;i < pos ;i++ )
		{
			b[i] = a[i];
		}
		
		b[i] = ele;

		for (; i < a.length;i++ )
		{
			b[i + 1] = a[i];
		}

		return b;
	}
}
