package package2;

public interface Itr3 extends Itr1,Itr2
{
	long z = 10L;
	void print();
}
