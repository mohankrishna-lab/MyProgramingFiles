package package2;

public class MainClassMutipleInherInterface
{
	public static void main(String[] args) {
		
		Iclass c = new Iclass();
		
		c.print();
		c.disp((int)32.3, (int)89.8);
		c.print(45);
	}
	
}
