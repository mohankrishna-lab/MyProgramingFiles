package package3;

public class MainIclass {

	public static void main(String[] args) {
		Iclass c = new Iclass();
		
		c.disp("hi", 30);
		c.print(67);
		System.out.println(c.x);
		System.out.println(c.d);

	}

}
