package package3;

public interface Itr1 
{
	int x = 9;
	void print(int x);
}
