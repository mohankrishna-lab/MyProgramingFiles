package package3;

public class Iclass implements Itr1,Itr2
{
	public void print(int x)
	{
		System.out.println(x);
	}
	
	public void disp(String s , int x)
	{
		System.out.println(s+x);
	}
}
