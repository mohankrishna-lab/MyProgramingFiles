package package3;

public interface Itr2 
{
	double d = 12.9;
	
	void disp(String s , int x);
}
