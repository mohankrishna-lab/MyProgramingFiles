class FindSpecificElementArrayString 
{
	public static void main(String[] args) 
	{
		String[] s = {"word" , "run" , "max" , "min"};
		String key = "min";

		findSpecificElement(s,key);
	}
	
	public static void findSpecificElement(String[] s , String key)
	{
		for (int i = 0;i < s.length ;i++ )
		{
			if (s[i].equals(key))
			{
				System.out.println("found");
			}
		}
	}
}
