class FirstNonReapeatedNumArray
{
	public static void main(String[] args) 
	{
		int[] a = {1,4,5,6,1,5,3,67,8};
		printFirstNonReapeatedNum(a);
	}

	public static void printFirstNonReapeatedNum(int[] a)
	{
		for (int i = 0;i < a.length ;i++ )
		{
			boolean flag = false;
			for (int j = i + 1;j < a.length ;j++ )
			{
				if (a[i] == a[j])
				{
					flag = true;
				}
			}
			if (!flag)
			{
				System.out.println(a[i]);
				break;
			}
		}

	}
}
