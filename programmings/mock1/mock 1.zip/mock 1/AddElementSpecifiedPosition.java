class AddElementSpecifiedPosition 
{
	public static void main(String[] args) 
	{
		int[] a = {1,3,45,6,7,8};

		int num = 43;

		int pos = 3;

		addElement(a,num,pos);
	}

	public static void addElement(int[] a,int num,int pos)
	{
		int[] b = new int[a.length + 1];
		
		int j = 0;
		int i = 0;
		for (;i < pos ;i++ )
		{
				b[j++] = a[i];
		}
		b[j] = num;
		for (;i <a.length ;i++ )
		{
			b[++j] = a[i];
		}

		for (int k = 0;k < b.length ;k++ )
		{
			System.out.println(b[k]);
		}
	}

}
