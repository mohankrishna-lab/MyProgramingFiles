class PrintAllArmstrongNumbers 
{
	public static void main(String[] args) 
	{
		int num = 10000;

		printArmstrongNum(num);
	}

	public static void printArmstrongNum(int num)
	{
		for (int i = 10;i <= num ;i++ )
		{
			int count= countDigits(i);
			if (isArmstrong(i , count))
			{
				System.out.println(i);
			}
		}
	}

	public static int countDigits(int num)
	{
		int count = 0;
		while (num > 0)
		{
			count++;
			num /= 10;
		}
		return count;
	}

	public static boolean isArmstrong(int num, int count)
	{
		int temp = num;
		int sum = 0;

		while (num > 0)
		{
			int rem = num % 10;

			sum = sum + (int)Math.pow(rem,count);

			num /= 10;
		}

		if (sum == temp)
		{
			return true;
		}
		return false;
	}
}
