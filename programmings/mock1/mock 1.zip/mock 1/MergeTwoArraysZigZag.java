class MergeTwoArraysZigZag 
{
	public static void main(String[] args) 
	{
		int[] a = {1,3,4,5,6,7};
		int[] b = {8,10,21,22,33,43,78,67,79};

		mergeZigZag(a , b);
	}

	public static void mergeZigZag(int[] a , int[] b)
	{
		int[] c = new int[a.length + b.length];

		int j = 0;
		int i = 0;

		for (;i < a.length && i < b.length ;i++ )
		{
			c[j++] = a[i];
			c[j++] = b[i];
		}

		while (i < a.length)
		{
			c[j++] = a[i++];
		}

		while (i < b.length)
		{
			c[j++] = b[i++];
		}

		for (int k = 0;k < c.length ;k++ )
		{
			System.out.println(c[k]);
		}
	}
}
