class PrintPairNumsSumEqualsNum 
{
	public static void main(String[] args) 
	{
		int[] a = {4,5,3,2,1,6,7};

		int num = 11;

		printPairNum(a , num);
	}

	public static void printPairNum(int[] a, int num)
	{
		for (int i = 0;i < a.length ;i++ )
		{
			for (int j = 0;j < a.length ;j++ )
			{
				if (a[i] + a[j] == num)
				{
					System.out.println("(" + a[1] + "," + a[j] + ")");
				}
			}
		}
	}
}
