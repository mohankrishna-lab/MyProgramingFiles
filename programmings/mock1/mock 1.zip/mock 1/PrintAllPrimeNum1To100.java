class PrintAllPrimeNum1To100 
{
	public static void main(String[] args) 
	{
		int num = 100;

		printPrime(num);
	}

	public static void printPrime(int num)
	{
		for (int i = 1;i <= num ;i++ )
		{
			if (isPrime(i))
			{
				System.out.println(i);
			}
		}
	}

	public static boolean isPrime(int num)
	{
		int count = 0;

		if (num == 0 || num == 1)
		{
			return false;
		}

		else
		{
			for (int i  = 2;i < num;i++ )
			{
				if (num % i == 0)
				{
					return false;
				}
			}
			}
		return true;
	}
}
