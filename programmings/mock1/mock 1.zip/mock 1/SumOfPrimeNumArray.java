class SumOfPrimeNumArray 
{
	public static void main(String[] args) 
	{
		int[] a = {2,5,6,7,8,9,10,11};

		sumPrime(a);
	}

	public static void sumPrime(int[] a)
	{
		int sum = 0;
		for (int i = 0;i < a.length ;i++ )
		{
			if (isPrime(a[i]))
			{
				sum = sum + a[i];
			}
			
		}

		System.out.println(sum);
	}

	public static boolean isPrime(int num)
	{
		int count = 0;

		if (num == 0 || num == 1)
		{
			return false;
		}

		else
		{
			for (int i  = 2;i < num;i++ )
			{
				if (num % i == 0)
				{
					return false;
				}
			}
			}
		return true;
	}
}
