class PrintAllMissingNumbersArray 
{
	public static void main(String[] args) 
	{
		int[] a = {1,4,6,7,8,9,24,25};

		printMissingNum(a);
	}

	public static void printMissingNum(int[] a)
	{
		for (int i = 0;i < a.length -1 ;i++ )
		{
			int j = a[i];
			if (a[i] != a[i + 1])
			{
				while (j < a[i+1] -1 )
				{
					
					System.out.println(++j);
				}
			}
		}
	}
}
