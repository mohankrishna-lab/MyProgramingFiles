class ReverseArray 
{
	public static void main(String[] args) 
	{
		int[] a = {45,5343,32,5767,9975,32,124};

		int[] b = reverseArray(a);

		for (int i = 0;i < b.length ;i++ )
		{
			System.out.println(b[i]);
		}
	}

	public static int[] reverseArray(int[] a)
	{
		for (int i = 0;i < a.length / 2 ;i++ )
		{
			int temp = a[i];
			
			a[i] = a[a.length - 1 - i];

			a[a.length - 1 - i] = temp;
		}

		return a;
	}
}
